# Note Denomination Calculator

Simple Android app for cash/denomination calculation.

Features:
- ₹500, ₹200, ₹100, ₹50, ₹20, ₹10, ₹1 denomination quantities
- Each denomination amount is calculated automatically
- POS 1, POS 2, POS 3, POS 4 and QR Code amounts
- Refund amount
- Declared/total amount field
- Grand total and difference
- MATCH / EXTRA / SHORT status
- Clear All button

Note: As requested, POS/QR/Refund values are added with x1. Refund is therefore treated as a positive amount.
