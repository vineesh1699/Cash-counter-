package com.example.denominationcalculator;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.NumberFormat;
import java.util.*;

public class MainActivity extends Activity {
    final int[] denoms = {500, 200, 100, 50, 20, 10, 1};
    final EditText[] noteInputs = new EditText[denoms.length];
    final EditText[] otherInputs = new EditText[5];
    final String[] otherNames = {"POS 1", "POS 2", "POS 3", "POS 4", "QR Code"};
    final int blue = Color.rgb(21,101,192);
    final int green = Color.rgb(46,125,50);
    final int red = Color.rgb(198,40,40);
    TextView cashTotal, otherTotal, grandTotal, difference, status;
    EditText declaredTotal, refundInput;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUI();
    }

    TextView tv(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(Color.DKGRAY);
        t.setPadding(12,10,12,10);
        return t;
    }

    EditText input() {
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setSingleLine(true); e.setGravity(Gravity.CENTER);
        e.setText("0"); e.setSelectAllOnFocus(true);
        return e;
    }

    void buildUI() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20,16,20,28);
        scroll.addView(root);

        TextView title = tv("NOTE DENOMINATION CALCULATOR", 22);
        title.setTextColor(blue); title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        root.addView(title);

        root.addView(tv("Denominations", 19));

        TableLayout table = new TableLayout(this);
        table.setStretchAllColumns(true);
        String[] headers = {"Denomination", "Qty", "Amount"};
        TableRow hr = new TableRow(this);
        for(String h: headers) { TextView x=tv(h,15); x.setTypeface(null,1); hr.addView(x); }
        table.addView(hr);

        for(int i=0;i<denoms.length;i++){
            TableRow r = new TableRow(this);
            TextView d = tv("₹ " + denoms[i], 16);
            noteInputs[i] = input();
            TextView amt = tv("₹ 0",16);
            amt.setGravity(Gravity.CENTER);
            final int idx=i;
            noteInputs[i].setOnFocusChangeListener((v,f)->{ if(!f) calculate(); });
            noteInputs[i].setOnKeyListener((v,key,event)->{ calculate(); return false; });
            r.addView(d); r.addView(noteInputs[i]); r.addView(amt);
            table.addView(r);
        }
        root.addView(table);

        cashTotal = tv("Cash Total: ₹ 0", 18);
        cashTotal.setTypeface(null,1);
        root.addView(cashTotal);

        root.addView(tv("POS / QR", 19));
        for(int i=0;i<4;i++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            TextView n = tv(otherNames[i],16);
            otherInputs[i]=input();
            row.addView(n,new LinearLayout.LayoutParams(0,55,1));
            row.addView(otherInputs[i],new LinearLayout.LayoutParams(0,55,1));
            root.addView(row);
        }
        LinearLayout qr = new LinearLayout(this);
        qr.setOrientation(LinearLayout.HORIZONTAL);
        TextView qn=tv("QR Code",16); otherInputs[4]=input();
        qr.addView(qn,new LinearLayout.LayoutParams(0,55,1));
        qr.addView(otherInputs[4],new LinearLayout.LayoutParams(0,55,1));
        root.addView(qr);

        otherTotal = tv("POS/QR Total: ₹ 0", 18);
        root.addView(otherTotal);

        root.addView(tv("Refund", 19));
        refundInput = input();
        root.addView(refundInput);

        root.addView(tv("ആകെ തുക / Declared Total", 19));
        declaredTotal = input();
        root.addView(declaredTotal);

        Button calc = new Button(this);
        calc.setText("CALCULATE");
        calc.setTextColor(Color.WHITE);
        calc.setBackgroundColor(blue);
        calc.setOnClickListener(v -> calculate());
        root.addView(calc);

        grandTotal = tv("Grand Total: ₹ 0", 20);
        grandTotal.setTypeface(null,1);
        root.addView(grandTotal);

        difference = tv("Difference: ₹ 0", 20);
        difference.setTypeface(null,1);
        root.addView(difference);

        status = tv("",18);
        status.setGravity(Gravity.CENTER);
        status.setTypeface(null,1);
        root.addView(status);

        Button clear = new Button(this);
        clear.setText("CLEAR ALL");
        clear.setOnClickListener(v -> clearAll());
        root.addView(clear);

        setContentView(scroll);
    }

    double val(EditText e) {
        try { return Double.parseDouble(e.getText().toString().trim()); }
        catch(Exception ex) { return 0; }
    }

    void calculate() {
        double cash=0, other=0;
        for(int i=0;i<denoms.length;i++) cash += denoms[i] * val(noteInputs[i]);
        for(EditText e: otherInputs) other += val(e);
        double refund = val(refundInput);
        double declared = val(declaredTotal);
        double grand = cash + other + refund;
        double diff = grand - declared;

        cashTotal.setText("Cash Total: " + money(cash));
        otherTotal.setText("POS/QR Total: " + money(other));
        grandTotal.setText("Grand Total: " + money(grand));
        difference.setText("Difference: " + money(diff));

        if(Math.abs(diff) < 0.005) {
            difference.setTextColor(green);
            status.setTextColor(green);
            status.setText("✓ MATCH — Amounts are equal");
        } else {
            difference.setTextColor(red);
            status.setTextColor(red);
            status.setText(diff > 0 ? "✗ EXTRA — " + money(diff) : "✗ SHORT — " + money(-diff));
        }
    }

    String money(double x) {
        return "₹ " + String.format(Locale.US, "%.2f", x);
    }

    void clearAll() {
        for(EditText e: noteInputs) e.setText("0");
        for(EditText e: otherInputs) e.setText("0");
        refundInput.setText("0");
        declaredTotal.setText("0");
        calculate();
    }
}
